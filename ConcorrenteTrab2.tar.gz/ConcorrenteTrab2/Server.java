import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;


public class Server {

	public static final int MAX_NUMBERS = 9999999;
    public static final int MAX_CLIENTS = 2;

	public static void public static void main(String[] args) {
		
		//Carrega a lista de códigos a encontrar
        List<String> codes = Files.readAllLines(Paths.get("hashes.txt"));
        //Lista de clientes
        List<Client> clients = new ArrayList<>();
        //Thread temporária
        Thread t;
        //Guarda a mensagem enviada por cada cliente
        String message;

        try{
        	ServerSocket server = new ServerSocket(5000, 2);  // (porta , clientes)
        	int faixa;
        	Runnable openSocket = new Runnable() {
        		public void run() {
        			
        			while(clients.size() <= MAX_CLIENTS) {

        				//for (String code : codes) {
        					
        					clients.add(new Client());
        					Socket socket = server.accept();
        					//cria saída de informação
        					ObjectOutputStream output = new ObjectOutputStream(c.getOutputStream());
        					output.flush();
        					//cria entrada de informação
        					ObjectInputStream input = new ObjectInputStream(c.getInputStream());
        					//converte a entrada em String
        					message = (String) input.readObject();
        					String answer = "Olá Cliente";
        					//responde aos objetos que enviaram alguma informação
        					output.writeObject(resposta);
        					output.flush();
        				//}
        				faixa = 0;        				
        			}
        		}
        	} catch (Exception e){e.printStackTrace();}

        	t = new Thread(openSocket).start();
        }
	}
}