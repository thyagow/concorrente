import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public class Client {

	private int start;
	private int edge;
	private ObjectInputStream input;
	private ObjectOutputStream output;
	private Socket socket;
	
	public Client() {
		setup();
		
		try {
			String answer = (String) input.readObject();
			output.writeObject("Olá Servidor");
			String message = (String) input.readObject();
		}	catch(Exception e){e.printStackTrace();}	

		/*for (int i = start; i <= edge; i++) 
			{
			    //Formata i com 7 casas (ex.: 0000000)
                String number = String.format("%07d", i);
                //Calcula o MD5 desse número
                String md5 = md5(number);

                //Verifica se o código produzido é igual ao do arquivo
                if (md5.equals(code))
                {
                    System.out.println("O código " + code + " é produzido pelo número " + number);
                    tempo = System.currentTimeMillis() - tempo;
                    System.out.println("O programa levou " + tempo + "ms para encontrar esse número.");
                }
        	}*/
	}

	public void setup() {
		long tempo = System.currentTimeMillis();
		
		try {
			socket = new Socket(InetAddress.getByName("127.0.0.1", 5000));
			output = new ObjectOutputStream(socket.getOutputStream());
			output.flush();
			input = new ObjectInputStream(socket.getInputStream());
		} catch(Exception e) {e.printStackTrace();}		
	}

	//Esta função produz um hash MD5 para a string de entrada
    public static String md5(String entrada) throws NoSuchAlgorithmException
    {
        MessageDigest sha1 = MessageDigest.getInstance("MD5");
        byte[] saida = sha1.digest(entrada.getBytes());
        StringBuilder saidaStr = new StringBuilder();
        for (byte b : saida)
            saidaStr.append(String.format("%02x", b));
        return saidaStr.toString();
    }
}